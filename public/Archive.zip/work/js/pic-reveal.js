//picture reveal

$(function () {



	$(document).on('load', 'img', function() {
		this.show();
		console.log('shit showin!');
	});

	
});