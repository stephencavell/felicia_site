$(function() {
	
	$('#contact-nav').on('click', function() {
		$('#contact_info').toggle();
		$('.photo-nav').toggle();
	});
})